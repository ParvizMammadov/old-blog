<?php $__env->startSection('content'); ?>
	<div id="templatemo_content_container">
        <div id="templatemo_content">
            <div id="templatemo_content_left">
				
                <div class="templatemo_post_wrapper">
                <div class="templatemo_post">
                    <div class="post_title">
                    	Free CSS Template</div>
                    <div class="post_info">
                    	Posted by <a href="#">TemplateMo.com</a>, December 7, 2024 at 10:12 am, in <a href="#">Player.</a>
                    </div>
                    <div class="post_body">
                        <img src="<?php echo e(asset('css/images/')); ?>/templatemo_image_02.jpg" alt="free css template" border="1" />
                      <p>Free CSS Template is provided by <a href="#">TemplateMo.com</a> for blog websites. You may download, modify and use this website layout for personal or commercial websites.</p>
                      <p>Credits go to <a rel="nofollow" href="http://www.bittbox.com/freebies/free-hi-resolution-wood-textures/" target="_blank">bittbox.com</a> for wood texture, <a rel="nofollow" href="http://www.brusheezy.com/brush/1108-Floral-Pack-1" target="_blank">ElenaSham</a> and <a rel="nofollow" href="http://www.brusheezy.com/brush/957-Enchanting-Flowers" target="_blank">Coby17</a> for brushes.</p>
                  </div>
              <div class="post_comment">
                    	<a href="#">No Comment</a>
                    </div>
                </div>
                </div> <!-- End of a post-->
                
                <div class="templatemo_post_wrapper">
                <div class="templatemo_post">
                    <div class="post_title">
                    	Blog web template for free</div>
                    <div class="post_info">
                    	Posted by <a href="#">TemplateMo.com</a>, December 6, 2024 at 11:24 am, in <a href="#">Player.</a>     
                    </div>
                    <div class="post_body">
                        <img src="<?php echo e(asset('css/images/')); ?>/templatemo_image_01.jpg" alt="free blog template" border="1" />
                      <p>                       Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nunc quis sem nec tellus blandit tincidunt. Duis vitae velit sed dui malesuada dignissim. Donec mollis aliquet ligula. Maecenas adipiscing elementum ipsum. Pellentesque vitae magna.</p>
                      <p>
                        Pellentesque dolor nulla, congue vitae, fringilla in, varius a, orci. Mauris convallis. Proin vel libero id erat venenatis accumsan. Nunc blandit orci sit amet risus. Donec mollis aliquet ligula. Maecenas adipiscing elementum ipsum.
                        </p>            
                    </div>
              <div class="post_comment">
                    	<a href="#">5 comments</a>
                    </div>
                </div>
                </div>  <!-- End of a post-->
                
            </div> <!-- end of content left -->
        
            <div id="templatemo_content_right">
            
            	<div class="templatemo_right_section">
					<div class="tag_section">
                        <ul id="countrytabs" class="shadetabs">
                            <li><a href="#" rel="search" class="selected">Search</a></li>                
                            <li><a href="#" rel="category">Category</a></li>
                            <li><a href="#" rel="archive">Archive</a></li>
                        </ul>
					</div>
				
                    <div class="tabcontent_section">
                        <div id="search" class="tabcontent">
                            <form method="get" action="#">
                                <input class="inputfield" name="searchkeyword" type="text" id="searchkeyword"/>
                                <input type="submit" name="submit" class="button" value="Search" />
                            </form>                    
                        </div>
					
                        <div id="category" class="tabcontent">
                            <ul>
                                <li><a href="#">Lorem ipsum</a></li>
                                <li><a href="#">Duis mollis</a></li>
                                <li><a href="#">Maecenas adipiscing</a></li>
                                <li><a href="#">Nunc blandit orci</a></li>
                                <li><a href="#">Cum sociis natoque</a></li>
                            </ul>                        
                        </div>
		            
                        <div id="archive" class="tabcontent">
                            <ul>
                                <li><a href="#">January 2009</a></li>
                                <li><a href="#">December 2008</a></li>
                                <li><a href="#">November 2008</a></li>
                                <li><a href="#">October 2008</a></li>
                                <li><a href="#">September 2008</a></li>
                            </ul>                         
                        </div>
					</div>

					<script type="text/javascript">
                    
                    var countries=new ddtabcontent("countrytabs")
                    countries.setpersist(true)
                    countries.setselectedClassTarget("link") //"link" or "linkparent"
                    countries.init()
                    
                    </script> <!--- end of tag -->
                </div>
            	
            
                <div class="templatemo_right_section">
                	<h2>Categories</h2>
					<ul>
                         
                            <li><a href="#">sfgrherf</a></li>
                        
                    </ul>    
                </div>
                
            </div> <!-- end of right content -->
	    </div> <!-- end of content -->
    </div> <!-- end of content container -->
<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\old-blog\resources\views/homepage.blade.php ENDPATH**/ ?>